from xml.etree import ElementTree as ET
from os import getcwd
from os.path import isdir
from os.path import isfile

def check_config_dir():
    try:
        current_path = getcwd() + '/Config'
        if not isdir(current_path):
                raise Exception("***ERROR : No existe el directorio de configuracion : " + current_path)

        return current_path

    except Exception as e:
        print str(e)


def check_configuration_file():
    try:
        current_path = check_config_dir() + "/Configuration.xml"

        if not isfile(current_path):
            raise Exception("***ERROR : No existe el fichero de configuracion : " + current_path)

        return current_path
    except Exception as e:
        print str(e)
    except IOError as e:
        str(e)

def check_simulator_file():
    try:
        current_path = check_config_dir() + "/SimulatorConfiguration.xml"
        if not isfile(current_path):
            raise Exception("***ERROR : No existe el fichero de configuracion : " + current_path)

        return current_path
    except Exception as e:
        print str(e)
    except IOError as e:
        str(e)

def get_simulator_tags():
    try:
        current_path = check_simulator_file()
        data = ET.parse(current_path)
        root = data.getroot()
        simulator_tags = root.findall("SimulatorConfiguration")
        return simulator_tags
    except IOError as e:
        str(e)

def get_motivEN_tags():
    try:
        current_path = check_configuration_file()
        data = ET.parse(current_path)
        root = data.getroot()
        motiven_tags = root.findall("MDBCoreConfiguration")
        return motiven_tags
    except IOError as e:
        str(e)

def get_CSE_tags():
    try:
        current_path = check_configuration_file()
        data = ET.parse(current_path)
        root = data.getroot()
        cse_tags = root.findall("CandidateStateEvaluatorConfiguration")
        return cse_tags
    except IOError as e:
        str(e)

def find_tag(tags, tag_name):
    value_tag = None
    try:
        for conf_tag in tags:
            value_tag = conf_tag.find(tag_name).text

        return value_tag
    except:
        print "No existe el tag : {0}".format(tag_name)

def get_log_directory(logger_type):
    current_path = getcwd() + "/Config"
    try:
        if isdir(current_path):
            current_path += "/LoggerConfiguration.xml"
            if not isfile(current_path):
                raise Exception("***ERROR : No existe el fichero de configuracion : " + current_path)
        else:
            raise Exception("***ERROR : No existe el directorio : " + current_path)

        data = ET.parse(current_path)
        root = data.getroot()
        directory_tags = root.findall(logger_type)
        directory = None
        for tag in directory_tags:
            directory = tag.find("logs_directory").text

        return str(directory)

    except Exception as e:
        print str(e)
    except IOError as e:
        str(e)
