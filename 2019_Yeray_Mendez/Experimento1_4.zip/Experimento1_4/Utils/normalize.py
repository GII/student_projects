import pandas as pd
from sklearn.preprocessing import MinMaxScaler

df = pd.read_csv('/home/yeray/PycharmProjects/TensorFlow/Data/datos_experimentoA.txt', sep=" ", header=None)
sensor_data = df.iloc[2:, :-1].values.astype(float)
scaler = MinMaxScaler()
scaler.fit(sensor_data)

class NormalizeFactory():

    def normalize(normalize_method, sensor_data):
        if normalize_method == "keras":
            return _normalize_data(sensor_data)


    normalize = staticmethod(normalize)

def _normalize_data(data):
    return scaler.transform(data)