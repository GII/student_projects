# coding=utf-8
import datetime
import numpy as np
import openpyxl
import pandas as pd
import os
import matplotlib.pyplot as plt


class VfEvaluationData(object):

    def __init__(self, name="data_evaluationMV"):
        self._train = []
        self._iterations_to_goal = []
        self._iterations = []
        self._extrinsic_iterations = []
        self._intrinsic_iterations = []

        now = datetime.datetime.now()
        self._name = '{0}{1}'.format(name, now.isoformat())

    def add_training(self, train_points):
        self._train += train_points

    def add_iterations(self, iteration, motivation):
        difference = iteration
        if motivation == 'Int':
            self._intrinsic_iterations.append(iteration)
        else:
            self._extrinsic_iterations.append(iteration)
        if len(self._iterations_to_goal) > 0:
            difference -= self._iterations_to_goal[-1]
        self._iterations_to_goal.append(iteration)
        self._iterations.append(difference)

    def save_data(self):
        self._print_graphics()
        self._store_info()
        self._write_file()

    def _write_file(self):
        file_name = self._name + '.txt'
        f = open(file_name, 'w+')
        data = ''
        for x in self._iterations_to_goal:
            data += '{0} \n'.format(x)
        data += '\n Intrinsic_Mot : '
        for x in self._intrinsic_iterations:
            data += '{0}, '.format(x)
        data += '\n Extrinsic_Mot : '
        for x in self._extrinsic_iterations:
            data += '{0}, '.format(x)
        data += '\n -------------------------\n'
        f.write(data)
        f.close()

    def _print_graphics(self):
        f, axarr = plt.subplots(1, 2)
        axarr[0].plot(np.arange(len(self._train)), self._train, 'b')
        axarr[0].set_title('Error de entrenamiento')
        axarr[0].set(xlabel='Epocas', ylabel='Error')
        axarr[1].plot(self._iterations_to_goal, 'ro')
        axarr[1].set_title('Iteraciones en las que alcanza el objetivo')
        axarr[1].set(xlabel='Iteraciones', ylabel='Objetivo ')
        plt.tight_layout()
        f.set_figheight(10)
        f.set_figwidth(17)
        img_name = self._name + '.png'
        f.savefig(img_name)

    def _store_info(self):
        file_name = self._name + '.xlsx'
        df = pd.DataFrame({
            'Nombre': [file_name],
            'Iteraciones medias': [np.mean(self._iterations)]
        })

        if os.path.isfile(file_name):
            wb = openpyxl.load_workbook(file_name)
            writer = pd.ExcelWriter(file_name, engine='openpyxl')
            writer.book = wb
            sheet = wb['Data']
            writer.sheets = dict((ws.title, ws) for ws in wb.worksheets)
            c = 0
            for _ in sheet:
                c += 1
            df.to_excel(writer, sheet_name='Data', header=False, index=False, columns=['Nombre',
                                                                                       'Iteraciones medias'],
                        startrow=c)
            writer.save()
        else:
            writer = pd.ExcelWriter(file_name, engine='openpyxl')
            wb = writer.book
            df.to_excel(writer, header=True, columns=['Nombre',
                                                      'Iteraciones medias'],
                        sheet_name='Data', index=False)
            wb.save(file_name)
