# coding=utf-8
from math import cos
from math import sin
from math import pi
from math import sqrt
import logging
import numpy as np
from math import atan2
from normalize import NormalizeFactory
from configuration_methods import get_CSE_tags
from configuration_methods import find_tag
logger = logging.getLogger('root')

MOBILE_POSITION_X_MIN = 0.35
MOBILE_POSITION_X_MAX = 0.9
MOBILE_POSITION_Y_MIN = -0.6
MOBILE_POSITION_Y_MAX = 0.6
BAXTER_POSITION_X_MIN = 0.5
BAXTER_POSITION_X_MAX = 0.7
BAXTER_POSITION_Y_MIN = -0.2
BAXTER_POSITION_Y_MAX = 0.3

tags = get_CSE_tags()
normalize_method = str(find_tag(tags, "methodToNormalized"))

def get_best_action(candidate_actions, sim_data, value_function, logger):
    robobo_pos = sim_data[2]
    robobo_vel = 0.1
    robobo_angle = sim_data[3]
    baxter_pos = sim_data[0]
    baxter_vel = 0.2
    baxter_angle = sim_data[1]
    ball_pos = sim_data[4]
    ball_owner = sim_data[5]
    goal_pos = sim_data[6]
    logger.info("Acciones candidatas generadas [{0}]".format(candidate_actions))
    #self._logger.info("Obtener mejor acción utiliando modelo de utilidad : {0}".format(self.utility_model_mode))
    future_positions = _get_future_positions(robobo_pos, robobo_vel, robobo_angle,
                                            baxter_pos, baxter_vel, baxter_angle,
                                            candidate_actions)
    logger.info("Posiciones futuras : [{0}]".format(future_positions))
    logger.info("La pelota la tiene el : [{0}]".format(ball_owner))
    distances_norm = _get_distances(ball_pos,
                                   goal_pos,
                                   future_positions,
                                   ball_owner)

    distances_norm = NormalizeFactory.normalize(normalize_method, distances_norm)
    logger.info("Distancias sin normalizar : {0}".format(distances_norm))
    logger.info("Distancias normalizadas : {0}".format(distances_norm))
    # if self._vf_run_mode == 'explotation':
    #     distances_norm = normalize_data(distances_norm)
    #self._logger.info("Distancias normalizadas : {0}".format(distances_norm))
    utility_predictions = _get_predictions_for_positions(distances_norm, value_function)
    logger.info("Distancias y utilidad [{0}]".format(utility_predictions))
    index = _get_best_utility_index(utility_predictions)
    # self._iteration_data.add_positions((self.simulator.robobo_get_pos(),
    #                                     self.simulator.baxter_larm_get_pos()))
    # self._iteration_data.add_future_positions(future_positions[index])
    # self._iteration_data.add_actions(candidate_actions[index])
    # self._iteration_data.add_utility(utility_predictions[index])
    # self._iteration_data.add_distances(distances_for_future_positions[index])
    # self._iteration_data.add_norm_distances((distances_norm[index]))
    logger.info('######################################')
    logger.info("Mejor accion : {0}".format(utility_predictions[index]))
    logger.info("Posición futura : {0}".format(future_positions[index]))
    logger.info("Distancia para acción : {0}".format(distances_norm[index]))
    logger.info("Distancia para acción normalizada : {0}".format(distances_norm[index]))
    logger.info('######################################')
    return candidate_actions[index]

def _degrees_to_radians(angles):
    return angles * pi / 180.0

def _get_future_position(robot_current_position, vel, angles, robot_type):
    x = robot_current_position[0] + vel * cos(_degrees_to_radians(angles))
    y = robot_current_position[1] + vel * sin(_degrees_to_radians(angles))

    if robot_type == "robobo":
        x, y = _future_position_robobo(x, y)
    else:
        x, y = _future_position_baxter(x, y)

    return x, y

def _future_position_baxter(x, y):
    if x < BAXTER_POSITION_X_MIN:
        corr = BAXTER_POSITION_X_MIN - x
        x += (corr + 0.05)
    if x > BAXTER_POSITION_X_MAX:
        corr = x - BAXTER_POSITION_X_MAX
        x -= (corr + 0.05)
    if y < BAXTER_POSITION_Y_MIN:
        corr = abs(y) - abs(BAXTER_POSITION_Y_MIN)
        y += (corr + 0.05)
    if y > BAXTER_POSITION_Y_MAX:
        corr = y - BAXTER_POSITION_Y_MAX
        y -= (corr + 0.05)

    return x, y

def _future_position_robobo(x, y):
    if x < MOBILE_POSITION_X_MIN:
        corr = MOBILE_POSITION_X_MIN - x
        x += (corr + 0.05)
    if x > MOBILE_POSITION_X_MAX:
        corr = x - MOBILE_POSITION_X_MAX
        x -= (corr + 0.05)
    if y < MOBILE_POSITION_Y_MIN:
        corr = abs(y) - abs(MOBILE_POSITION_Y_MIN)
        y += (corr + 0.05)
    if y > MOBILE_POSITION_Y_MAX:
        corr = y - MOBILE_POSITION_Y_MAX
        y -= (corr + 0.05)

    return x, y

def _get_future_positions(robobo_current_position, vel_robobo, robobo_angles,
                         baxter_current_position, vel_baxter, baxter_angles,
                         candidates_angles):
    future_positions = []
    b_angles = baxter_angles
    r_angles = robobo_angles
    for angles in candidates_angles:
        b_angles += angles[1]
        r_angles += angles[0]
        robobo_pos = _get_future_position(robobo_current_position,
                                          vel_robobo,
                                          r_angles,
                                          "robobo")
        baxter_pos = _get_future_position(baxter_current_position,
                                          vel_baxter,
                                          angles[1],
                                          "baxter")
        future_positions.append((robobo_pos, baxter_pos))
        b_angles = baxter_angles
        r_angles = robobo_angles
    return future_positions

def _get_distance(x1, y1, x2, y2):
    return sqrt(pow(x2 - x1, 2) + (pow(y2 - y1, 2)))

def _get_distances(ball_position, box_position, robots_positions, ball_catched):
    distances = []
    shape = (len(robots_positions), 3)
    for position in robots_positions:
        ball_box = _get_distance(ball_position[0], ball_position[1], box_position[0], box_position[1])
        if ball_catched == 'robobo':
            robobo_ball = 0
        else:
            robobo_ball = _get_distance(position[0][0], position[0][1], ball_position[0], ball_position[1])
        if ball_catched == 'baxter_larm':
            baxter_ball = 0
        else:
            baxter_ball = _get_distance(position[1][0], position[1][1], ball_position[0], ball_position[1])
        distances.append([robobo_ball, baxter_ball, ball_box])

    distances = np.array(distances).reshape(shape)

    return distances

def _get_best_utility_index(utility_predictions):
    index = 0
    max_utility = 0
    pos = 0
    for utility in utility_predictions:
        if utility[1] > max_utility:
            max_utility = utility[1]
            index = pos
        pos += 1

    return index

def _radians_to_degrees(angles):
    return angles * 180.0 / pi


def _calculate_angle(baxter_pos, robobo_pos, block_pos):
    angles_robobo = atan2((block_pos[1] - robobo_pos[1]),
                          (block_pos[0] - robobo_pos[0]))
    angles_baxter = atan2((block_pos[1] - baxter_pos[1]),
                          (block_pos[0] - baxter_pos[0]))

    angles_robobo = _radians_to_degrees(angles_robobo)
    angles_baxter = _radians_to_degrees(angles_baxter)

    return angles_robobo, angles_baxter

def _get_predictions_for_positions(distances, value_function):
    prediction = []
    for item_data in distances:
        utility = _model_utility_predict(value_function, item_data)
        prediction.append((item_data, utility))
    return prediction

def _model_utility_predict(value_function, data):
    utility = None
    data = data.reshape((1, 3)).astype(np.float32)
    utility = value_function.predict(data)
    utility = utility[0][0]
    return utility
