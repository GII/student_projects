#!/bin/bash
cd /home/yeray/ros_ws/
./baxter.sh