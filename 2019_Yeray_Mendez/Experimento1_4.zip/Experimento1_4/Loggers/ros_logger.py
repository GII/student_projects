import logging
import rospy
from Utils.configuration_methods import get_log_directory
import datetime

directory = get_log_directory("rospy")
now = datetime.datetime.now()
file_name = '{0}LogFile{1}.log'.format(directory, now.isoformat())

class RosLogger(logging.Handler):

    configure = False
    file = open(file_name, 'a+')
    MAP = {
        logging.DEBUG:rospy.logdebug,
        logging.INFO:rospy.loginfo,
        logging.WARNING:rospy.logwarn,
        logging.ERROR:rospy.logerr,
        logging.CRITICAL:rospy.logfatal
    }
    LEVEL = {
        10:"DEBUG",
        20:"INFO",
        30:"WARNING",
        40:"ERROR",
        50:"CRITICAL"
    }

    def emit(self, record):
        try:
            self.MAP[record.levelno]("%s: %s" % (record.name, record.msg))
            self.file.write("[%s]-%s : %s \n" % (self.LEVEL[record.levelno], record.name, record.msg))
        except KeyError:
            rospy.logerr("unknown log level %s LOG: %s: %s" % (record.levelno, record.name, record.msg))
        except ValueError as error:
            rospy.logerr(error)