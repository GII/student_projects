import logging
from Utils.configuration_methods import get_log_directory
import datetime


class LoggerFactory():

    def get_logger(simulator):
        if simulator == "2d":
            directory = get_log_directory("logging")
            now = datetime.datetime.now()
            file_name = '{0}LogFile{1}.log'.format(directory,now.isoformat())
            logging.basicConfig(format="%(levelname)s-[%(asctime)s]:{%(filename)s-%(funcName)s(%(lineno)s)}: %(message)s",
                                filename=file_name, level=logging.DEBUG)
            return logging.getLogger("root")

        from ros_logger import RosLogger
        logger = logging.getLogger("root")
        logger.addHandler(RosLogger())
        logger.setLevel(logging.DEBUG)

        return logger

    get_logger = staticmethod(get_logger)