#!/bin/bash
source /home/yeray/ros_ws/devel/setup.bash
python MDBCore.py