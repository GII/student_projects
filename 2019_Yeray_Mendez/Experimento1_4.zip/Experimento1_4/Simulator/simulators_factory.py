from Simulador import Sim
from simulador_gazebo import SimuladorGazebo
from Utils.configuration_methods import get_simulator_tags
from Utils.configuration_methods import find_tag


class SimulatorFactory(object):

    def get_simulator(simulator_name):
        try:
            if simulator_name == "gazebo":
                tags = get_simulator_tags()
                return SimuladorGazebo(vel_robobo=float(find_tag(tags, "despl_robobo")),
                                       vel_baxter=float(find_tag(tags, "despl_baxter")))
            elif simulator_name == "2d":
                return Sim()
            else:
                raise Exception("***ERROR : El simulador {0} no tiene implementacion".format(simulator_name))
        except Exception as e:
            print str(e)

    get_simulator = staticmethod(get_simulator)
