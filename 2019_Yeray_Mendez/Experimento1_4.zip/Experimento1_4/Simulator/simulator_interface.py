from abc import ABCMeta
import abc


class SimulatorInterface(object):
    __metaclass__ = ABCMeta

    @abc.abstractmethod
    def get_sensorization(self):
        """
        :rtype: list/tuple
        """
        pass

    @abc.abstractmethod
    def get_reward(self):
        """
        :rtype: int
        """
        pass

    @abc.abstractmethod
    def restart_scenario(self):
        """
        :rtype: void
        """
        pass

    @abc.abstractmethod
    def apply_action(self, action, iterations):
        """
        :rtype: void
        """
        pass
