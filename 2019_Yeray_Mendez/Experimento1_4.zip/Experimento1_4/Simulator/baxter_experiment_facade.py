from Simulator.simulator_interface import SimulatorInterface
import abc
from abc import ABCMeta


class BaxterExperiment(SimulatorInterface):

    __metaclass__ = ABCMeta

    @abc.abstractmethod
    def baxter_larm_get_pos(self):
        pass

    @abc.abstractmethod
    def baxter_larm_get_angle(self):
        pass

    @abc.abstractmethod
    def baxter_rarm_get_pos(self):
        pass

    @abc.abstractmethod
    def baxter_rarm_get_angle(self):
        pass

    @abc.abstractmethod
    def robobo_get_pos(self):
        pass

    @abc.abstractmethod
    def robobo_get_angle(self):
        pass

    @abc.abstractmethod
    def ball_get_pos(self):
        pass

    @abc.abstractmethod
    def ball_position(self):
        pass

    @abc.abstractmethod
    def box_get_pos(self):
        pass
