from baxter_experiment_facade import BaxterExperiment
import struct
import copy
import rospy
from gazebo_msgs.msg import ModelStates
from gazebo_msgs.msg import ModelState
from gazebo_msgs.srv import SetModelState
from geometry_msgs.msg import Twist
from geometry_msgs.msg import Pose
from geometry_msgs.msg import PoseStamped
from geometry_msgs.msg import Quaternion
from geometry_msgs.msg import Point
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion
from std_msgs.msg import Header
from baxter_core_msgs.srv import SolvePositionIK
from baxter_core_msgs.srv import SolvePositionIKRequest
import baxter_interface
from random import uniform
from math import sqrt
from math import pow
from math import pi
from math import cos
from math import sin
from math import atan2
import logging
import threading

BLOCK = 'block'
MOBILE_ROBOT = 'mobile_robot'
GOAL = 'goal'
BAXTER_LARM = 'baxter_larm'
BOX = 'box1'
ROBOBO = 'robobo'
MOBILE_INIT_POSE = Pose(position=Point(x=0.5, y=-0.3, z=0.1))
NEUTRAL_ORIENTATION = Quaternion(x=0, y=1, z=0, w=0)
CORRECCION_X = 0.025
CORRECCION_Y = 0.035
CORRECCION_Z = -0.130
POSICION_Z = 0.9
MOBILE_POSITION_X_MIN = 0.35
MOBILE_POSITION_X_MAX = 0.9
MOBILE_POSITION_Y_MIN = -0.6
MOBILE_POSITION_Y_MAX = 0.6
BAXTER_POSITION_X_MIN = 0.5
BAXTER_POSITION_X_MAX = 0.7
BAXTER_POSITION_Y_MIN = -0.2
BAXTER_POSITION_Y_MAX = 0.3
DIST_X = 0.09
DIST_Y = 0.09

class SimuladorGazebo(BaxterExperiment):

    def __init__(self, vel_robobo, vel_baxter, verbose=1, hover_distance=0.17):
        rospy.init_node("motivEN")
        self._log = logging.getLogger('root')
        self._log.info("Arrancado nodo motivEN")
        self._log.info("Velocidades de los robots : Robobo : {0}, Baxter {1}".format(vel_robobo, vel_baxter))
        self._vel_robobo = vel_robobo
        self._vel_baxter = vel_baxter
        self._pos_block = None
        self._pos_goal = None
        self._hover_distance = hover_distance
        self._left_arm = baxter_interface.limb.Limb("left")
        self._left_joint_names = self._left_arm.joint_names()
        self._left_gripper = baxter_interface.gripper.Gripper('left')
        self._rate = rospy.Rate(1)
        self._verbose = verbose
        ns = "ExternalTools/" + 'left' + "/PositionKinematicsNode/IKService"
        self._IK = rospy.ServiceProxy(ns, SolvePositionIK, persistent=True)
        rospy.wait_for_service('/gazebo/set_model_state')
        self._set_model_service = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState, persistent=True)
        rospy.wait_for_service('/gazebo/set_model_state', 5.0)
        self._first = True
        self._block_pose = None
        self._mobile_yaw = None
        self._baxter_larm_last_angle = None
        x, y = self._generate_random_position(False)
        self._baxter_current_pose = Pose(position=Point(x=x, y=y, z=CORRECCION_Z),
                                         orientation=NEUTRAL_ORIENTATION)
        self._approach(self._baxter_current_pose)
        self._ball_position = None
        self._reward = 0
        self._init_subs_pubs()
        self._block_pose = None
        self._robobo_current_angles = 0
        self._baxter_larm_current_angles = 0
        rospy.on_shutdown(self._shutdown)
        rospy.sleep(1)
        self._actual_pos = 0

    def _shutdown(self):
        self._set_neutral()
        self._stop()
        self._sub1.unregister()
        self._sub2.unregister()
        self._publisher.unregister()
        x = round(uniform(MOBILE_POSITION_X_MIN, MOBILE_POSITION_X_MAX - (2 * CORRECCION_X)), 4)
        y = round(uniform(MOBILE_POSITION_Y_MIN, MOBILE_POSITION_Y_MAX - CORRECCION_Y), 4)
        pose = Pose(
            position=Point(x, y, 0.1))
        self._set_element_to_pose(MOBILE_ROBOT, pose)
        rospy.sleep(1)
        (x, y), (x1, y1) = self._generate_random_pose_for_objects()
        goal_pose = Pose(position=Point(x=x1, y=y1, z=0.1))
        self._set_element_to_pose(GOAL, goal_pose)
        rospy.sleep(1)
        #x, y = self._generate_random_pose()
        block_pose = Pose(position=Point(x=x, y=y, z=0.1),
                          orientation=NEUTRAL_ORIENTATION
                          )
        self._set_element_to_pose(BLOCK, block_pose)
        rospy.sleep(1)
        self._first = False
        self._reward = 0
        self._ball_position = None
        self._approach(self._baxter_current_pose)

    def _generate_random_pose_for_objects(self):
        x = round(uniform(MOBILE_POSITION_X_MIN, MOBILE_POSITION_X_MAX - (2 * CORRECCION_X)), 4)
        y = round(uniform(MOBILE_POSITION_Y_MIN, MOBILE_POSITION_Y_MAX - CORRECCION_Y), 4)
        x1 = round(uniform(BAXTER_POSITION_X_MIN, BAXTER_POSITION_X_MAX - (2 * CORRECCION_X)), 4)
        y1 = round(uniform(BAXTER_POSITION_Y_MIN, BAXTER_POSITION_Y_MAX - CORRECCION_Y), 4)

        while (self._diference(x, x1) < 0.2) and (self._diference(y, y1)) < 0.2 and (self._diference(x, self._mobile_position_x)) and (self._diference(x1, self._mobile_position_x)) and (self._diference(y, self._mobile_position_y)) and (self._diference(y1, self._mobile_position_y)):
            x = round(uniform(BAXTER_POSITION_X_MIN, BAXTER_POSITION_X_MAX - (2 * CORRECCION_X)), 4)
            y = round(uniform(BAXTER_POSITION_Y_MIN, BAXTER_POSITION_Y_MAX - CORRECCION_Y), 4)
            x1 = round(uniform(BAXTER_POSITION_X_MIN, BAXTER_POSITION_X_MAX - (2 * CORRECCION_X)), 4)
            y1 = round(uniform(BAXTER_POSITION_Y_MIN, BAXTER_POSITION_Y_MAX - CORRECCION_Y), 4)

        return (x, y), (x1, y1)

    def baxter_larm_get_pos(self):
        x = self._baxter_current_pose.position.x
        y = self._baxter_current_pose.position.y

        return x, y

    def baxter_larm_get_angle(self):
        angles = self._baxter_larm_current_angles

        return angles

    def baxter_rarm_get_pos(self):
        pass

    def baxter_rarm_get_angle(self):
        pass

    def robobo_get_pos(self):
        return self._mobile_position_x, self._mobile_position_y

    def robobo_get_angle(self):
        return self._robobo_current_angles

    def ball_get_pos(self):
        x = self._block_pose.position.x
        y = self._block_pose.position.y

        return x, y

    def ball_position(self):
        return self._ball_position

    def box_get_pos(self):
        x = self._goal_pose.position.x
        y = self._goal_pose.position.y

        return x, y

    def get_sensorization(self):
        """Return a sensorization vector with the distances between the ball and the robots' actuators and the reward"""
        dist_rob_ball = self._get_distance_robobo_ball()
        dist_baxt_larm_ball = self._get_distance_left_baxter_arm_block()
        dist_ball_box1 = self._get_distance_block_goal()

        return dist_rob_ball, dist_baxt_larm_ball, dist_ball_box1

    def get_reward(self):
        return self._reward

    def restart_scenario(self):
        self._log.info('Restart experiment')
        self._reboot_scenario()

    def apply_action(self, angles, iterations):
        self._log.info("Angles robobo : {2} | {0}, Angles Baxter {1}".format(angles[0], angles[1], self._robobo_current_angles))
        self._log.info("Block pose: x:{0}, y:{1} | Goal pose: x:{2}, y:{3}".format(self._block_pose.position.x,
                                                                                  self._block_pose.position.y,
                                                                                  self._goal_pose.position.x,
                                                                                  self._goal_pose.position.y))
        self._log.debug("Ball catched by : {0}".format(self._ball_position))
        self._robots_movement(angles)
        self._log.info("Finish action : The ball is catched by  : {0}".format(self._ball_position))

    def _init_subs_pubs(self):
        self._sub1 = rospy.Subscriber("/gazebo/model_states", ModelStates, self._get_model_state)
        self._sub2 = rospy.Subscriber('/odom', Odometry, self._get_odometry)
        self._publisher = rospy.Publisher('/cmd_vel', Twist, queue_size=1)

    def _get_model_state(self, msg):
        if self._pos_block is None and self._pos_goal is None:
            self._get_coordinates(msg)
        else:
            self._get_block_coordinates(msg)
            self._get_goal_coordinates(msg)

    def _get_coordinates(self, msg):
        pos = 0
        for name in msg.name:
            if name == BLOCK:
                self._pos_block = pos
                self._get_block_coordinates(msg)
            elif name == GOAL:
                self._pos_goal = pos
                self._get_goal_coordinates(msg)
            pos += 1

    def _get_block_coordinates(self, msg):
        pose = msg.pose[self._pos_block]
        x1 = 0
        y1 = 0
        if self._block_pose is not None:
            x1 = round(self._block_pose.position.x, 3)
            y1 = round(self._block_pose.position.y, 3)
        x2 = round(pose.position.x, 3)
        y2 = round(pose.position.y, 3)
        # if pose.position.z < 0.7:
        #     self._reboot_scenario()
        if self._block_pose is None or (x1 != x2 and y1 != y2):
            if self._first:
                block_x = pose.position.x + CORRECCION_X
            else:
                block_x = pose.position.x - CORRECCION_X
            block_y = pose.position.y + (CORRECCION_Y/2)
            self._block_pose = Pose(position=Point(x=block_x, y=block_y, z=CORRECCION_Z),
                                    orientation=NEUTRAL_ORIENTATION)

    def _get_goal_coordinates(self, msg):
        pose = msg.pose[self._pos_goal]
        goal_x = pose.position.x + CORRECCION_X
        goal_y = pose.position.y + CORRECCION_Y
        goal_z = CORRECCION_Z
        self._goal_pose = Pose(position=Point(x=goal_x, y=goal_y, z=goal_z),
                               orientation=NEUTRAL_ORIENTATION)

    def _get_odometry(self, msg):
        self._mobile_position_x = msg.pose.pose.position.x
        self._mobile_position_y = msg.pose.pose.position.y
        self._mobile_position_z = msg.pose.pose.position.z
        mobile_robot_orientation = msg.pose.pose.orientation
        orientation_list = [mobile_robot_orientation.x,
                            mobile_robot_orientation.y,
                            mobile_robot_orientation.z,
                            mobile_robot_orientation.w]
        (_, _, self._mobile_yaw) = euler_from_quaternion(orientation_list)

    def _set_neutral(self):
        self._left_arm.move_to_neutral()

    def _ik_request(self, pose):
        hdr = Header(stamp=rospy.Time.now(), frame_id='base')
        ikreq = SolvePositionIKRequest()
        ikreq.pose_stamp.append(PoseStamped(header=hdr, pose=pose))
        try:
            resp = self._IK(ikreq)
        except (rospy.ServiceException, rospy.ROSException), e:
            rospy.logerr("Service call failed: %s" % (e,))
            return False
        resp_seeds = struct.unpack('<%dB' % len(resp.result_type), resp.result_type)
        limb_joints = {}
        if (resp_seeds[0] != resp.RESULT_INVALID):
            seed_str = {
                ikreq.SEED_USER: 'User Provided Seed',
                ikreq.SEED_CURRENT: 'Current Joint Angles',
                ikreq.SEED_NS_MAP: 'Nullspace Setpoints',
            }.get(resp_seeds[0], 'None')
            # #if self._verbose:
            # rospy.loginfo("IK Solution SUCCESS - Valid Joint Solution Found from Seed Type: {0}".format((seed_str)))
            # Format solution into Limb API-compatible dictionary
            limb_joints = dict(zip(resp.joints[0].name, resp.joints[0].position))
            '''#if self._verbose:
                rospy.loginfo("IK Joint Solution:\n{0}".format(limb_joints))
                rospy.loginfo("------------------")'''
        else:
            rospy.logerr("INVALID POSE - No Valid Joint Solution Found.")
            limb_joints = None
            # raise Exception('INVALID POSE - No Valid Joint Solution Found.')
        return limb_joints

    def _guarded_move_to_joint_position(self, joint_angles):
        if joint_angles:
            self._left_arm.move_to_joint_positions(joint_angles)
        else:
            rospy.logerr("No Joint Angles provided for move_to_joint_positions. Staying put.")

    def _gripper_open(self):
        self._left_gripper.open()
        rospy.sleep(1.0)

    def _gripper_close(self):
        self._left_gripper.close()
        rospy.sleep(1.0)

    def _approach(self, pose):
        approach = copy.deepcopy(pose)
        approach.position.z = approach.position.z + self._hover_distance
        try:
            joint_angles = self._ik_request(approach)
            if joint_angles is not None:
                self._guarded_move_to_joint_position(joint_angles)
        except:
            self._log.error('Error al calcular posicion del brazo')

    def _retract(self):
        current_pose = self._left_arm.endpoint_pose()
        ik_pose = Pose()
        ik_pose.position.x = current_pose['position'].x
        ik_pose.position.y = current_pose['position'].y
        ik_pose.position.z = current_pose['position'].z + self._hover_distance
        ik_pose.orientation.x = current_pose['orientation'].x
        ik_pose.orientation.y = current_pose['orientation'].y
        ik_pose.orientation.z = current_pose['orientation'].z
        ik_pose.orientation.w = current_pose['orientation'].w
        joint_angles = self._ik_request(ik_pose)
        if joint_angles is not None:
            self._guarded_move_to_joint_position(joint_angles)

    def _pick(self, pose):
        # open the gripper
        self._gripper_open()
        # servo above pose
        self._approach(pose)
        # servo to pose
        self._servo_to_pose(pose)
        # close gripper
        self._gripper_close()
        # retract to clear object
        self._retract()

    def _place(self, pose):
        # servo above pose
        self._approach(pose)
        # servo to pose
        self._servo_to_pose(pose)
        # open the gripper
        self._gripper_open()
        # retract to clear object
        self._retract()

    def _servo_to_pose(self, pose):
        joint_angles = self._ik_request(pose)
        if joint_angles is not None:
            self._guarded_move_to_joint_position(joint_angles)

    def _publish_message(self, msg):
        if self._publisher is not None:
            self._publisher.publish(msg)

    def _go_forward(self, potence=0.05):
        msg = Twist()
        msg.linear.x = potence
        msg.angular.z = 0.0
        self._publish_message(msg)
        #self._log.debug('Finish movement')

    def _stop(self):
        msg = Twist()
        msg.linear.x = 0.0
        msg.angular.z = 0.0
        self._publish_message(msg)

    def _rotate(self, potence=0.05):
        msg = Twist()
        msg.linear.x = 0.0
        msg.angular.z = potence
        self._publish_message(msg)

    def _degrees_to_radians(self, angles):
        return angles * pi / 180.0

    def _radians_to_degrees(self, angles):
        return angles * 180.0 / pi

    def _get_distance(self, x1, y1, x2, y2):
        """Return the distance between two points"""
        return sqrt(pow(x2 - x1, 2) + (pow(y2 - y1, 2)))

    def _get_distance_robobo_ball(self):
        distance = 0.0
        x1 = self._mobile_position_x
        y1 = self._mobile_position_y
        x2 = self._block_pose.position.x
        y2 = self._block_pose.position.y
        if self._ball_position != ROBOBO:
            distance = self._get_distance(x1, y1, x2, y2)
        return distance

    def _get_distance_block_goal(self):
        distance = 0.0
        x1 = self._block_pose.position.x
        y1 = self._block_pose.position.y
        x2 = self._goal_pose.position.x
        y2 = self._goal_pose.position.y
        if self._ball_position != BOX:
            distance = self._get_distance(x1, y1, x2, y2)
        return distance

    def _get_distance_left_baxter_arm_block(self):
        distance = 0.0
        x1 = self._baxter_current_pose.position.x
        y1 = self._baxter_current_pose.position.y
        x2 = self._block_pose.position.x
        y2 = self._block_pose.position.y
        if self._ball_position != BAXTER_LARM:
            distance = self._get_distance(x1, y1, x2, y2)
        return distance

    def _diference(self, x, y):
        dif = 0
        if x > 0 and y < 0:
            dif = x + y
        elif x < 0 and y > 0:
            dif = y + x
        else:
            dif = abs(x - y)

        return dif

    def _generate_random_position(self, is_goal):
        x = round(uniform(BAXTER_POSITION_X_MIN, BAXTER_POSITION_X_MAX - (2 * CORRECCION_X)), 4)
        y = round(uniform(BAXTER_POSITION_Y_MIN, BAXTER_POSITION_Y_MAX - CORRECCION_Y), 4)
        if is_goal:
            while self._diference(y, self._mobile_position_y) < 0.2 and self._diference(x, self._mobile_position_x) < 0.2:
                x = round(uniform(BAXTER_POSITION_X_MIN, BAXTER_POSITION_X_MAX - (2 * CORRECCION_X)), 4)
                y = round(uniform(BAXTER_POSITION_Y_MIN, BAXTER_POSITION_Y_MAX - CORRECCION_Y), 4)
        return x, y

    def _generate_random_pose(self):
        x = round(uniform(MOBILE_POSITION_X_MIN, MOBILE_POSITION_X_MAX - (2 * CORRECCION_X)), 4)
        y = round(uniform(MOBILE_POSITION_Y_MIN, MOBILE_POSITION_Y_MAX - CORRECCION_Y), 4)
        while self._diference(y, self._mobile_position_y) < 0.2 and self._diference(x, self._mobile_position_x) < 0.2 and self._diference(
                x, self._goal_pose.position.x) < 0.2 and self._diference(y, self._goal_pose.position.y) < 0.2:
            x = round(uniform(MOBILE_POSITION_X_MIN, MOBILE_POSITION_X_MAX - (2 * CORRECCION_X)), 4)
            y = round(uniform(MOBILE_POSITION_Y_MIN, MOBILE_POSITION_Y_MAX - CORRECCION_Y), 4)
        return x, y

    def _reboot_scenario(self):
        self._set_neutral()
        (x, y), (x1, y1) = self._generate_random_pose_for_objects()
        goal_pose = Pose(position=Point(x=x1, y=y1, z=0.1))
        self._set_element_to_pose(GOAL, goal_pose)
        block_pose = Pose(position=Point(x=x, y=y, z=0.1),
                          orientation=NEUTRAL_ORIENTATION
                          )
        self._set_element_to_pose(BLOCK, block_pose)
        self._first = False
        self._reward = 0
        self._ball_position = None
        self._approach(self._baxter_current_pose)

    def _reset_robobo(self):
        self._set_neutral()
        self._stop()
        pose = Pose(position=Point(x=self._mobile_target_position_x, y=self._mobile_target_position_y, z=0.1),
                    orientation=Quaternion(x=0, y=0, z=self._degrees_to_radians(self._robobo_current_angles), w=1))
        self._set_element_to_pose(MOBILE_ROBOT, pose)
        if self._ball_position == ROBOBO:
            self._set_element_to_pose(BLOCK, pose)
        self._approach(self._baxter_current_pose)

    def _get_potence(self):
        potence = 0.05
        actual_degrees = self._radians_to_degrees(self._mobile_yaw)
        if self._robobo_current_angles > 0 and actual_degrees > 0:
            if actual_degrees < self._robobo_current_angles:
                potence = -0.05
        elif self._robobo_current_angles < 0 and actual_degrees < 0:
            if self._robobo_current_angles > actual_degrees:
                potence = -0.05
        else:
            if self._robobo_current_angles > 0 and actual_degrees <= 0:
                if actual_degrees > -90 and self._robobo_current_angles < 90:
                    potence = -0.05
            elif self._robobo_current_angles < 0 and actual_degrees >= 0:
                if actual_degrees > 90 and self._robobo_current_angles < -90:
                    potence = -0.05
        return potence

    def _robobo_near_limit(self):
        near = False
        limit_x_max = abs((self._mobile_position_x + 10) - MOBILE_POSITION_X_MAX)
        limit_x_min = abs((self._mobile_position_x - 10) - MOBILE_POSITION_X_MIN)
        limit_y_max = abs((self._mobile_position_y + 10) - MOBILE_POSITION_Y_MAX)
        limit_y_min = abs((self._mobile_position_y - 10) - MOBILE_POSITION_Y_MIN)
        if limit_x_max < 0.1 or limit_x_min < 0.1 or limit_y_max < 0.1 or limit_y_min:
            near = True

        return near

    def _move_robobo(self, go_to_baxter=False):
        logging.debug("ROBOBO is moving")
        stop = False
        run = False
        is_runing = False
        self._rotate(potence=self._get_potence())
        while not stop:
            if self._mobile_position_z < 0.8 or self._mobile_position_x > 0.95 or self._mobile_position_x < 0.3 or self._mobile_position_y > 0.7 or self._mobile_position_y < -0.7:
                self._reset_robobo()
                stop = True
            if run:
                if not is_runing:
                    self._go_forward()
                    is_runing = True
                else:
                    position_x = abs(self._mobile_target_position_x - self._mobile_position_x)
                    position_y = abs(self._mobile_target_position_y - self._mobile_position_y)
                    self._log.info("Distancia x: {0}, y : {1}".format(position_x, position_y))
                    if self._ball_position == ROBOBO or self._ball_position == BAXTER_LARM:
                        if position_x < 0.1 and position_y < 0.1:
                            self._stop()
                            #self._log.debug('GOAL')
                            stop = True
                    else:
                        if (position_x < 0.1 and position_y < 0.1) or self._mobile_near_block():
                            self._stop()
                            #self._log.debug('GOAL')
                            if self._mobile_near_block():
                                self._set_neutral()
                                pose = Pose(
                                    position=Point(self._mobile_position_x, self._mobile_position_y, 0.1),
                                    orientation=NEUTRAL_ORIENTATION)
                                self._set_element_to_pose(BLOCK, pose)
                                self._ball_position = ROBOBO
                            stop = True
            else:
                '''current = self._radians_to_degrees(self._mobile_yaw)
                difference = atan2(sin(current - self._robobo_current_angles),
                                   cos(current - self._robobo_current_angles))'''
                difference = atan2((self._mobile_target_position_y - self._mobile_position_y),
                                   (self._mobile_target_position_x - self._mobile_position_x))
                if go_to_baxter:
                    difference = atan2((self._baxter_current_pose.position.y - self._mobile_position_y),
                                       (self._baxter_current_pose.position.x - self._mobile_position_x))

                '''#self._log.info('ANGLES : CURRENT : {0}, GOAL : {1}, REST : {2}'.format(self._mobile_yaw,
                                                                                       self._degrees_to_radians(
                                                                                           self._robobo_current_angles),
                                                                                       subs))
                #self._log.info('ANGLES (degrees) : CURRENT : {0}, GOAL : {1}, REST : {2}'.format(self._radians_to_degrees(
                                                                                        self._mobile_yaw),
                                                                                       self._robobo_current_angles,
                                                                                       abs(self._robobo_current_angles-self._radians_to_degrees(
                                                                                        self._mobile_yaw))))'''
                if abs(self._degrees_to_radians(self._robobo_current_angles) - self._mobile_yaw) < 0.1:
                    self._stop()
                    run = True
            self._rate.sleep()

    def _robobo_calculate_pose(self, angles):
        recalculate = False
        x, y = self._calculate_pose(self._mobile_position_x,
                                    self._mobile_position_y,
                                    self._vel_robobo,
                                    self._robobo_current_angles)
        if x < MOBILE_POSITION_X_MIN:
            corr = MOBILE_POSITION_X_MIN - x
            x += (corr + 0.05)
            #x = MOBILE_POSITION_X_MIN
            recalculate = True
        if x > MOBILE_POSITION_X_MAX:
            corr = x - MOBILE_POSITION_X_MAX
            x -= (corr + 0.05)
            #x = MOBILE_POSITION_X_MAX
            recalculate = True
        if y < MOBILE_POSITION_Y_MIN:
            corr = abs(y) - abs(MOBILE_POSITION_Y_MIN)
            y += (corr + 0.05)
            #y = MOBILE_POSITION_Y_MIN
            recalculate = True
        if y > MOBILE_POSITION_Y_MAX:
            corr = y - MOBILE_POSITION_Y_MAX
            y -= (corr + 0.05)
            #y = MOBILE_POSITION_Y_MAX
            recalculate = True

        # self._log.info('ACTUAL POSITION : X : {0}, Y : {1} | GOAL X : {2}, Y : {3}'.format(self._mobile_position_x,
        #                                                                                   self._mobile_position_y,
        #                                                                                   x,
        #                                                                                   y))
        self._mobile_target_position_x = x
        self._mobile_target_position_y = y

        if recalculate:
            self._recalculate_angle()

    def _recalculate_angle(self):
        # self._log.info('X : initial {0}, goal {1}'.format(self._mobile_position_x,
        #                                                    self._mobile_target_position_x))
        # self._log.info('Y : initial {0}, goal {1}'.format(self._mobile_position_y,
        #                                                    self._mobile_target_position_y))
        inc_x = self._mobile_target_position_x - self._mobile_position_x
        inc_y = self._mobile_target_position_y - self._mobile_position_y
        angles = atan2(inc_y, inc_x)
        self._robobo_current_angles = self._radians_to_degrees(angles)
        # self._log.info("Actual degrees : {0}, Goal : {1}".format(self._radians_to_degrees(self._mobile_yaw),
        #                                                          self._robobo_current_angles))

    def _baxter_calculate_pose(self, angles):
        x, y = self._calculate_pose(self._baxter_current_pose.position.x,
                                    self._baxter_current_pose.position.y,
                                    self._vel_baxter,
                                    angles
                                    )

        if x < BAXTER_POSITION_X_MIN:
            corr = BAXTER_POSITION_X_MIN - x
            x += (corr + 0.05)
        if x > BAXTER_POSITION_X_MAX:
            corr = x - BAXTER_POSITION_X_MAX
            x -= (corr + 0.05)
        if y < BAXTER_POSITION_Y_MIN:
            corr = abs(y) - abs(BAXTER_POSITION_Y_MIN)
            y += (corr + 0.05)
        if y > BAXTER_POSITION_Y_MAX:
            corr = y - BAXTER_POSITION_Y_MAX
            y -= (corr + 0.05)

        # self._log.info("Baxter current pose : x:{0}, y:{1}".format(self._baxter_current_pose.position.x,
        #                                                            self._baxter_current_pose.position.y))

        self._baxter_current_pose = Pose(position=Point(x=x, y=y, z=CORRECCION_Z),
                                         orientation=NEUTRAL_ORIENTATION
                                         )
        # self._log.info("Baxter target pose: x:{0}, y:{1}".format(self._baxter_current_pose.position.x,
        #                                                          self._baxter_current_pose.position.y))

    def _calculate_pose(self, pos_x, pos_y, vel, angles):
        x = pos_x + vel * cos(self._degrees_to_radians(angles))
        y = pos_y + vel * sin(self._degrees_to_radians(angles))
        return x, y

    def _mobile_near_block(self):
        near = False
        distance_to_block_x = abs(self._block_pose.position.x - self._mobile_position_x)
        distance_to_block_y = abs(self._block_pose.position.y - self._mobile_position_y)
        if distance_to_block_x < 0.15 and distance_to_block_y < 0.15:
            near = True
        return near

    def _set_element_to_pose(self, name, pose, reference_frame='base'):
        model_state = ModelState()
        model_state.model_name = name
        model_state.pose = pose
        model_state.reference_frame = reference_frame
        self._set_model_service(model_state)

    def _set_baxter_angles(self, angles):
        self._baxter_larm_current_angles += angles
        if self._baxter_larm_current_angles >= 180:
            self._baxter_larm_current_angles -= 180
        elif self._baxter_larm_current_angles <= -180:
            self._baxter_larm_current_angles += 180

    def _set_robobo_angles(self, angles):
        self._robobo_current_angles += angles
        if self._robobo_current_angles >= 180:
            self._robobo_current_angles = -180 + abs(self._robobo_current_angles - 180)
        elif self._robobo_current_angles <= -180:
            self._robobo_current_angles = 180 - abs(self._robobo_current_angles + 180)

    def _robots_movement(self, angles):
        self._set_robobo_angles(angles[0])
        self._set_baxter_angles(angles[1])
        self._baxter_calculate_pose(angles[1])
        self._robobo_calculate_pose(angles[0])
        if self._is_same_target():
            #self._log.debug("Robobo give block to Baxter")
            self._move_robobo(True)
            self._leave_block()
            return
        elif self._is_block_pose():
            #self._log.debug("Baxter to BLOCK POSITION")
            self._pick(self._block_pose)
            self._ball_position = BAXTER_LARM
        elif self._is_on_goal():
            if abs(self._mobile_position_x - self._goal_pose.position.x) < 0.15 and abs(
                    self._mobile_position_y - self._goal_pose.position.y) < 0.15:
                self._set_element_to_pose(MOBILE_ROBOT, Pose(position=Point(10, 0, 0)))
            #self._log.debug("Baxter to GOAL POSITION")
            self._place(self._goal_pose)
            self._ball_position = BOX
            self._reward = 1
            self._set_neutral()
            pose = Pose(position=Point(x=self._mobile_target_position_x, y=self._mobile_target_position_y, z=0.1),
                        orientation=Quaternion(x=0, y=0, z=self._degrees_to_radians(self._robobo_current_angles),
                                               w=1))
            self._set_element_to_pose(MOBILE_ROBOT, pose)
            return
        else:
            self._approach(self._baxter_current_pose)
        self._move_robobo()

    def _leave_block(self):
        self._stop()
        self._set_neutral()
        self._set_element_to_pose(MOBILE_ROBOT, Pose(position=Point(10, 0, 0)))
        pos_x = self._baxter_current_pose.position.x + CORRECCION_X
        block_pose = Pose(position=Point(pos_x, self._baxter_current_pose.position.y - (CORRECCION_Y / 2), 0.1),
                          orientation=NEUTRAL_ORIENTATION
                          )
        self._set_element_to_pose(BLOCK, block_pose)
        self._pick(self._baxter_current_pose)
        self._ball_position = BAXTER_LARM
        self._set_neutral()
        self._set_element_to_pose(MOBILE_ROBOT, Pose(
            position=Point(x=self._mobile_target_position_x, y=self._mobile_target_position_y, z=0.1),
            orientation=Quaternion(x=0, y=0, z=self._degrees_to_radians(self._robobo_current_angles), w=1)))
        self._approach(self._baxter_current_pose)
        rospy.sleep(0.5)

    def _is_same_target(self):
        same_target = False
        distance_x = abs(self._mobile_target_position_x - self._baxter_current_pose.position.x)
        distance_y = abs(self._mobile_target_position_y - self._baxter_current_pose.position.y)

        if (distance_x < 0.15 and distance_y < 0.15) and self._ball_position == ROBOBO:
            same_target = True

        return same_target

    def _is_block_pose(self):
        is_block_pose = False

        distance_x = abs(self._block_pose.position.x - self._baxter_current_pose.position.x)
        distance_y = abs(self._block_pose.position.y - self._baxter_current_pose.position.y)

        if distance_x < DIST_X and distance_y < DIST_Y and self._ball_position is None:
            is_block_pose = True

        return is_block_pose

    def _is_on_goal(self):
        is_on_goal = False
        if self._ball_position == BAXTER_LARM:
            if self._get_distance_block_goal() < 0.15:
                is_on_goal = True
        return is_on_goal
