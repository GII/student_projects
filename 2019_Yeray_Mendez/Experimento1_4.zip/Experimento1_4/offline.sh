#!/bin/bash
rosrun gazebo_ros spawn_model -file /home/yeray/ros_ws/src/simulator/models/table/model.sdf -sdf -x 0.6 -y 0.0 -z -0.2 -Y 1.57  -model table -reference_frame world
rosrun gazebo_ros spawn_model -file /home/yeray/ros_ws/src/simulator/models/mobile_robot/model.sdf -sdf -reference_frame base -x 0.4 -y -0.3 -z 0.1 -model mobile_robot
rosrun gazebo_ros spawn_model -file /home/yeray/ros_ws/src/simulator/models/goal/model.urdf -urdf -reference_frame base -x 0.5 -y 0.1 -z 0.1 -model goal
rosrun gazebo_ros spawn_model -file /home/yeray/ros_ws/src/simulator/models/block/model.urdf -urdf -reference_frame base -x 0.8 -y 0.35 -z 0.1 -model block
