from abc import ABCMeta
import abc


class ValueFunctionsManagerInterface(object):
    __metaclass__ = ABCMeta

    def __init__(self):
        self._value_function_list = []

    @abc.abstractmethod
    def create_value_function(self, type):
        pass

    @abc.abstractmethod
    def get_value_function(self, index):
        pass

    @abc.abstractmethod
    def get_best_value_function_by_sensorization(self, sensorization):
        pass

    @abc.abstractmethod
    def add_value_function(self, value_function):
        pass

    @abc.abstractmethod
    def remove_value_function(self, value_function):
        pass

    @abc.abstractmethod
    def get_value_functions_size(self):
        pass

    @abc.abstractmethod
    def get_active_vf(self):
        pass

    @abc.abstractmethod
    def get_certainty(self, sensorial_state):
        pass