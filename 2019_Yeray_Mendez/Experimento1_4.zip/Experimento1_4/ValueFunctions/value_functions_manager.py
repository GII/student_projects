from numpy import ufunc

from value_functions_manager_interface import ValueFunctionsManagerInterface
import logging
from value_function_factory import ValueFunctionFactory


class ValueFunctionsManager(ValueFunctionsManagerInterface):

    def __init__(self):
        ValueFunctionsManagerInterface.__init__(self)
        self._current_vf = None
        self._threshold = 0.1
        self._logger = logging.getLogger('root')

    def get_certainty(self, sensorial_state):
        certainty = 0
        if self._current_vf is not None:
            vf_certainty = self._value_function_list[self._current_vf].get_certainty(sensorial_state)
            self._logger.info('-- CERTEZA ACTUAL : [{0}]  --'.format(self._value_function_list[self._current_vf].get_certainty(sensorial_state)))
            if self._value_function_list[self._current_vf].get_certainty(sensorial_state) > self._threshold:
                certainty = 1
        return certainty

    def get_active_vf(self):
        return self._value_function_list[self._current_vf]

    def create_value_function(self, value_function):
        self.add_value_function(ValueFunctionFactory.get_value_function(value_function))
        if len(self._value_function_list) == 1:
            self._current_vf = 0

    def get_value_function(self, index):
        return self._value_function_list[index]

    def get_best_value_function_by_sensorization(self, sensorization):
        minimal_certainty = 0
        index = -1
        pos = 0
        if len(self._value_function_list) == 1:
            self._current_vf = 0
            return self._value_function_list[self._current_vf]
        for value_function in self._value_function_list:
            certainty = value_function.get_certainty(sensorization)
            if certainty > minimal_certainty:
                minimal_certainty = certainty
                index = pos
            pos += 1
            self._current_vf = index
        return self._value_function_list[self._current_vf]

    def add_value_function(self, value_function):
        logging.info("Adding new value function\n")
        self._value_function_list.append(value_function)

    def remove_value_function(self, value_function):
        logging.info("Removing the value function\n")
        del self._value_function_list[self._value_function_list.index(value_function)]

    def get_value_functions_size(self):
        return len(self._value_function_list)


# m = ValueFunctionsManager()
# m.create_value_function("keras")
# vf = m.get_active_vf()
# import pandas as pd
# import numpy as np
# df = pd.read_csv('/home/yeray/PycharmProjects/TensorFlow/Data/datos_experimentoA.txt', sep=" ", header=None)
# sensor_data = df.iloc[2:, :-1].values.astype(float)
# utility = df.iloc[2:, 3:].values.astype(float)
# def get_next_trace(x_data, y_data):
#     x_data_list = []
#     y_data_list = []
#     initial_index = 0
#     order = 0
#     for i in range(x_data.shape[0]):
#         if y_data[i][0] == 1:
#             x_data_list.append((order, x_data[initial_index:i+1, :]))
#             y_data_list.append((order,y_data[initial_index:i+1, :]))
#             initial_index = i + 1
#             order += 1
#     return x_data_list, y_data_list
#
# x_data, y_data = get_next_trace(sensor_data, utility)
# for i in range(len(x_data)):
#     vf.train(x_data[i][1], y_data[i][1], epochs=30, batch_size=len(x_data[i][1]))