from tensorflow.nn import relu
from tensorflow.keras.initializers import random_normal
from keras_neural_network import KerasNeuralNetwork
import tensorflow.keras.initializers as initializer
normal = initializer.random_normal(stddev=0.1, seed=101)
class ValueFunctionFactory:

    def get_value_function(value_function_name):
        vf = None
        if value_function_name == "keras":
            model_file='/home/yeray/Escritorio/MDBCore/Experimento1_4/ValueFunctions/model.hdf5'
            vf = KerasNeuralNetwork()

        return vf

    get_value_function = staticmethod(get_value_function)