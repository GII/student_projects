from abc import ABCMeta
import abc
from DistancesCertainty import DistancesCertainty


class ValueFunctionInterface(object):
    __metaclass__ = ABCMeta

    def __init__(self):
        self._certainty_map = DistancesCertainty()

    @abc.abstractmethod
    def add_trace(self, trace):
        pass

    @abc.abstractmethod
    def add_weak_trace(self, weak_trace):
        pass

    @abc.abstractmethod
    def add_anti_trace(self, anti_trace):
        pass

    @abc.abstractmethod
    def get_certainty(self, sensorization):
        pass

    @abc.abstractmethod
    def predict(self, input_data):
        pass

    @abc.abstractmethod
    def train(self, input_data, output_data):
        pass