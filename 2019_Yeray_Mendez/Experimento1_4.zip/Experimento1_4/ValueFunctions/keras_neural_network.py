import pandas as pd
import sys
from sklearn.preprocessing import MinMaxScaler
sys.path.append("/home/yeray/Escritorio/MDBCore/Experimento1_4")
from value_function_interface import ValueFunctionInterface
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.models import load_model
from tensorflow.keras.models import save_model
from tensorflow.nn import relu
from tensorflow.keras.initializers import random_normal
from tensorflow.keras.callbacks import ModelCheckpoint
import os
import logging
model_file = "/home/yeray/Escritorio/MDBCore/Experimento1_4/ValueFunctions/model.hdf5"


class KerasNeuralNetwork(ValueFunctionInterface):

    def __init__(self,
                 input_neurons=3,
                 output_neurons=1,
                 neurons_by_hidden_layer=[10, 3],
                 act_func=[relu, relu, relu],
                 kernels=[random_normal(stddev=0.1, seed=101),
                          random_normal(stddev=0.1, seed=101),
                          random_normal(stddev=0.1, seed=101)],
                 biases=['ones', 'ones', 'ones'],
                 loss='mse',
                 optimizer='adam',
                 metrics=[],
                 verbose=1,
                 model_file=None):
        ValueFunctionInterface.__init__(self)
        self.log = logging.getLogger('root')
        self.input_neurons = input_neurons
        self.output_neurons = output_neurons
        self.loss = loss
        self.optimizer = optimizer
        self.metrics = metrics
        self.initial_epoch = 0
        self.epochs = 0
        self.hidden_layers = neurons_by_hidden_layer
        self.verbose = verbose
        self.model_file = model_file
        self.model = self.initialize_model(kernels, biases, act_func)
        self.compile()

    def initialize_model(self, kernels, biases, act_fn):
        # Create model
        model = Sequential()
        if len(kernels) == 1:
            model.add(Dense(self.output_neurons,
                            input_dim=self.input_neurons,
                            kernel_initializer=kernels[0],
                            bias_initializer=biases[0],
                            activation=act_fn[0]))
        else:
            for i in range(len(kernels)):
                if i == 0:
                    model.add(Dense(self.hidden_layers[i],
                                    input_dim=self.input_neurons,
                                    kernel_initializer=kernels[i],
                                    bias_initializer=biases[i],
                                    activation=act_fn[i]))
                elif i == (len(kernels) - 1):
                    model.add(Dense(self.output_neurons,
                                    kernel_initializer=kernels[i],
                                    bias_initializer=biases[i],
                                    activation=act_fn[i]))
                else:
                    model.add(Dense(self.hidden_layers[i],
                                    kernel_initializer=kernels[i],
                                    bias_initializer=biases[i],
                                    activation=act_fn[i]))

        self.log.info("Modelo inicializado")
        return model

    def compile(self):
        # Compile model
        try:
            if self.model_file is not None:
                self.log.info("Compilando modelo guardado {0}".format(self.model_file))
                self.model = load_model(self.model_file)
            else:
                self.log.info("Compilando modelo : loss : {0}, optimizador : {1}".format(self.loss,
                                                                                        self.optimizer))
                self.model.compile(loss=self.loss, optimizer=self.optimizer, metrics=self.metrics)
            # if self.model_file is not None:
            #     self.log.info("Compilando modelo guardado {0}".format(self.model_file))
            #     self.model = load_model(self.model_file)
        except ValueError as e:
            self.log.error("*** Error al compilar modelo : {0}".format(e))

    def save_model(self, model_file):
        # Save the model and the weights
        try:
            save_model(self.model, model_file, include_optimizer=True)
        except ImportError as e:
            print e

    def load_model(self, model_file):
        # Load model and weights
        try:
            self.log.info("Cargando modelo")
            self.model = load_model(model_file)
        except ImportError as e:
            self.log.error("*** Error al cargar modelo : {0}".format(e))
        except ValueError as e:
            self.log.error("*** Error al cargar modelo : {0}".format(e))

    def train(self, input_data, output_data, batch_size=None, epochs=10, callback=[]):
        history = None
        self.epochs += epochs
        try:
            history = self.model.fit(input_data,
                                      output_data,
                                      batch_size=batch_size,
                                      epochs=self.epochs,
                                      verbose=self.verbose,
                                      callbacks=callback,
                                      initial_epoch=self.initial_epoch)

            self.initial_epoch += epochs
        except ValueError as e:
            self.log.error('*** Error en entrenamiento : {0}'.format(e))
        except RuntimeError as _:
            self.log.error('*** Error en entrenamiento : Debes compilar el modelo antes de entrenar.')

        return history

    def predict(self, input_data):
        predictions = None
        try:
            predictions = self.model.predict(input_data, verbose=self.verbose)
        except ValueError as e:
            self.log.error('*** Error al predecir : {0}'.format(e))

        return predictions

    def evaluate(self, input_data, output_data, batch_size=None):
        loss = None
        try:
            self.log.info("Evaluando al modelo...")
            loss = self.model.evaluate(input_data,
                                        output_data,
                                        batch_size=batch_size,
                                        verbose=self.verbose)
        except ValueError as e:
            self.log.error('*** Error el evaluar modelo : {0}'.format(e))
        except RuntimeError as e:
            self.log.error('*** Error el evaluar modelo : {0}'.format(e))

        return loss

    def get_model(self):
        return self.model

    def add_trace(self, trace):
        self.log.info("Agregando traza : {0}".format(trace))
        self._certainty_map.addTraces(trace)

    def add_weak_trace(self, weak_trace):
        self.log.info("Agregando traza debil : {0}".format(weak_trace))
        self._certainty_map.addWeakTraces(weak_trace)

    def add_anti_trace(self, anti_trace):
        self.log.info("Agregando anti-traza : {0}".format(anti_trace))
        self._certainty_map.addAntiTraces(anti_trace)

    def get_certainty(self, sensorization):
        certainty = self._certainty_map.getCertaintyValue(sensorization)
        self.log.info("Certeza de la VF : {0}".format(certainty))
        return certainty
