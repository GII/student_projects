from Utils.configuration_methods import get_motivEN_tags
from Utils.configuration_methods import find_tag
from Loggers.logger_factory import LoggerFactory

class MDBCoreConfiguration(object):

    def __init__(self):
        tags = get_motivEN_tags()
        self._logger = LoggerFactory.get_logger(str(find_tag(tags, "simulator_type")))
        self.max_iterations = int(find_tag(tags, "max_iterations"))
        self.activeMot = str(find_tag(tags, "initial_motivation"))
        self.traces_to_train = int(find_tag(tags, "traces_to_train"))
        self.goal_traces = 0
        self.noMotivManager = 0
        if self.activeMot == 'Ext':
            self.noMotivManager = 1
        self.useVF = int(find_tag(tags, "use_value_function"))
        self.trained_vf = int(find_tag(tags, "trained_vf"))
        self.simulator_name = str(find_tag(tags, "simulator_type"))


